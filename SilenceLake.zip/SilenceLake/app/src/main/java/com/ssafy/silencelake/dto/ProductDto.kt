package com.ssafy.silencelake.dto

data class ProductDto(val id: Int, var name: String, var nameEng: String,var type: String, var price: Int, var img: String) {
}