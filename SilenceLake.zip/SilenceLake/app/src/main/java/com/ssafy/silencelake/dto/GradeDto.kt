package com.ssafy.silencelake.dto

data class GradeDto(var img: String, var step: Int, var to: Int, var title: String) {
}